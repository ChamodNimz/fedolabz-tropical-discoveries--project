<?php 
	require_once '../core/init.php';

//header table get
	$no = $_POST['no'];

	$query="SELECT `ID_H`,`typeName`, `voucherDate`, `hotelName`, `AmendCount`, `receivedFrom`, `guestName`, `nationality`, `roomCategory`, `mealPlan`, `arrivalDate`, `departureDate`, `roomsCount`, `nightCount`, `single`, `double`, `triple`, `rate`, `extra`, `req` FROM `voucherh` where status='pending' and voucherNo='$no' ";
	$dataSet=mysqli_query($connection,$query);
	$row1=mysqli_fetch_array($dataSet);


	// $query="SELECT count(status) as cnt FROM `voucherh` WHERE status ='amended' and voucherNo='$no'";
	// $dataSet=mysqli_query($connection,$query);
	// $row=mysqli_fetch_array($dataSet);

	// $query="SELECT  `guestName`, `roomType`, `roomCatagory`, `mealPlan`, `checkIn`, `checkOut`, `roomCount`, `extras`, `specialRequest`, `ADL`, `CHD` FROM `voucherd` WHERE voucherNo='$no'";
	// $dataSet=mysqli_query($connection,$query);
	// while($row=mysqli_fetch_array($dataSet)){
		
	// }

	$data= array_merge($row1);
	$a=json_encode($data);
	echo $a;
 ?>