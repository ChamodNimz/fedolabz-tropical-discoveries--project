<?php 
	require_once '../core/init.php';

	$vNo= $_POST['no'];
	$query="SELECT `guestName`, `roomCategory`, `mealPlan`, `arrivalDate`, `departureDate`, `roomsCount`,
     `single`,`double`,`triple` FROM `voucherh` WHERE voucherNo ='$vNo' ";
	$dataSet= mysqli_query($connection,$query);

 ob_start();	
	while($row= mysqli_fetch_array($dataSet)):
 ?>

 <tr>
          <td><?php echo $row['guestName'] ?></td>
          <td><?php echo $row['roomCategory'] ?></td>
          <td><?php echo $row['mealPlan'] ?></td>
          <td><?php echo $row['arrivalDate'] ?></td>
          <td><?php echo $row['departureDate'] ?></td>
          <td><?php echo $row['roomsCount'] ?></td>
          <td><?php echo $row['single'] ?></td>
          <td><?php echo $row['double'] ?></td>
          <td><?php echo $row['triple'] ?></td>
</tr>

<?php endwhile; ?>
<?php ob_flush();  ?>
<?php echo ob_get_flush(); ?>