<?php 

define('BASEURL','hotel/' );

$connection=mysqli_connect("localhost","root","","hotel");


		if(mysqli_connect_error()){
			echo"connection failed to esatablish : Error Code - ".mysqli_connect_error()."";
		}

session_start();

function isLoggedIn(){

	if(isset($_SESSION['userID'])){

		return true;
	}
	else{
		
		return false;
	}

}

function isAdmin(){
	if(isset($_SESSION['userID']) && $_SESSION['userType']=='admin'){
		return true;
	}
	else{
		return false;
	}
}

function isUser(){
	if(isset($_SESSION['userID']) && $_SESSION['userType']=='user'){
		return true;
	}
	else{
		return false;
	}
}
		
?>