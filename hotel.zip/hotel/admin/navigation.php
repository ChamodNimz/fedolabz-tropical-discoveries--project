    <nav class="navbar navbar-expand-md navbar-danger bg-warning">
      <div class="container">
       

        <div class="collapse navbar-collapse navbar-light" id="navbarsExample05">
          <ul class="navbar-nav ml-auto pl-lg-5 pl-0">
            
            <li class="nav-item">
              <a class="nav-link " href="index.php">Add hotel</a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="addMeal.php">Add meal</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="addRoomCat.php">Add room category</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="addReceiver.php">Add receiver</a>
            </li>
            <li class="nav-item">
              <a class="nav-link " href="../Voucher.php">Main Menu</a>
            </li>
            <li class="nav-item">
            	<a href="logout.php" class=" btn btn-danger btn-sm rounded"  role="button">Logout</a>
            </li>
            
          </ul>
          
        </div>
      </div>
    </nav>
  